Create 热源 -> 农夫乐事 兼容补丁 / Create heat sources for Farmer's Delight
Minecraft 1.21.1 / NeoForge / 数据包 pack_format 48

【作用】
把机械动力及其附属的锅炉热源方块写入 farmersdelight:heat_sources 标签，
使农夫乐事厨锅、煎锅、以及所有读取该标签的加热设备（发酵桶、额外乐事烤炉/降温器等）能识别它们。

包含的方块：
  create:blaze_burner           烈焰人燃烧室
  create:lit_blaze_burner       点燃的烈焰人燃烧室
  create_new_age:heater         机械动力：电气时代 / 锅炉加热器
  createdieselgenerators:burner 柴油发电机：燃烧器（未安装该模组时会被自动忽略）

【安装方式，任选一种】
1) 存档级：解压后把整个 create-heat-fix 文件夹放进
   .minecraft/saves/<存档名>/datapacks/
   进游戏执行 /reload  或 /datapack list 确认启用。
   也可以直接把 create-heat-fix.zip 丢进 datapacks 文件夹（不用解压）。

2) 整合包全局级（推荐，所有存档生效）：
   - 装了 KubeJS：放到 .minecraft/kubejs/data/farmersdelight/tags/block/heat_sources.json
   - 装了 OpenLoader：放到 .minecraft/config/openloader/data/create-heat-fix/
   - 装了 Paxi：放到 .minecraft/config/paxi/datapacks/create-heat-fix/

3) 服务器：放到 <服务器根目录>/world/datapacks/

【注意】
烈焰人燃烧室本身没有 LIT 方块状态，标签只负责“这个方块算不算热源”。
是否真的在发热、以及 1~3 级热源对烹饪速度的加成，由机械动力：中央厨房（CCK）的 Mixin
读取 Create 的 BoilerHeater 注册表来判断，因此：
  - 熄灭的燃烧室 / 未通电的锅炉加热器 仍然不会加热（CCK 正常工作时）
  - 如果 CCK 版本与 Create / 农夫乐事不匹配导致 Mixin 失效，就会变成"永远是热源"，
    但至少能正常烹饪。

【版本要求（1.21.1）】
  Create             6.0.10
  Create: Dragons Plus（机械动力：龙+）  1.11.9+
  Create: Central Kitchen（机械动力：中央厨房）2.6.2b
  Farmer's Delight（农夫乐事）  1.3.2+
